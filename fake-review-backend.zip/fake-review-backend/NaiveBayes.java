import java.util.*;

/** Simple Naive Bayes text classifier (fake vs genuine) with Laplace smoothing. */
public class NaiveBayes {
    private final Map<String, Integer> fakeCounts = new HashMap<>();
    private final Map<String, Integer> realCounts = new HashMap<>();
    private final Set<String> vocab = new HashSet<>();
    private int fakeTokens, realTokens, fakeDocs, realDocs;

    public void train(String text, boolean fake) {
        for (String t : ReviewAnalyzer.tokenize(text)) {
            vocab.add(t);
            if (fake) { fakeCounts.merge(t, 1, Integer::sum); fakeTokens++; }
            else      { realCounts.merge(t, 1, Integer::sum); realTokens++; }
        }
        if (fake) fakeDocs++; else realDocs++;
    }

    /** Returns P(fake | text) between 0 and 1. */
    public double probFake(String text) {
        List<String> tokens = ReviewAnalyzer.tokenize(text);
        double logRatio = Math.log((double) fakeDocs / realDocs);
        int v = vocab.size();
        for (String t : tokens) {
            double pf = (fakeCounts.getOrDefault(t, 0) + 1.0) / (fakeTokens + v);
            double pr = (realCounts.getOrDefault(t, 0) + 1.0) / (realTokens + v);
            logRatio += Math.log(pf / pr);
        }
        logRatio /= Math.sqrt(Math.max(1, tokens.size()));   // normalise for length
        return 1.0 / (1.0 + Math.exp(-logRatio * 1.5));
    }
}
