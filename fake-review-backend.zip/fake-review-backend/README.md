# Fake Review Detector - Backend

Java 17+ REST API, no external libraries. Detection = Naive Bayes classifier + rule-based red flags
(hype words, links, duplicates, rating mismatch, etc.). It only serves JSON.

## Files
Main.java (REST API) | ReviewAnalyzer.java | NaiveBayes.java | TrainingData.java | Demo.java

## Run
```
javac *.java
java Main            # port 8080
java Main 9000       # custom port
```

Restrict which frontend may call the API (default is `*`):
```
ALLOWED_ORIGIN=http://localhost:3000 java Main
```

## Console demo (no frontend needed)
```
java Demo
```

## API
| Method | Path | Body | Response |
|---|---|---|---|
| POST | `/api/analyze` | `{"review": "text", "rating": 5}` | `{score, verdict, naiveBayes, ruleScore, reasons[]}` |
| GET | `/api/history` | none | `[{review, verdict, score}]` |
