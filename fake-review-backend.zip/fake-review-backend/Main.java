import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** Standalone REST API backend. The frontend is a separate app and is not served from here. */
public class Main {
    private static final ReviewAnalyzer analyzer = new ReviewAnalyzer();
    // Origin of the frontend allowed to call this API. Override with: ALLOWED_ORIGIN=http://localhost:3000 java Main
    private static final String ALLOWED_ORIGIN = System.getenv().getOrDefault("ALLOWED_ORIGIN", "*");
    private static final List<String[]> history = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/api/analyze", Main::handleAnalyze);
        server.createContext("/api/history", Main::handleHistory);
        server.start();
        System.out.println("Backend API running on http://localhost:" + port);
        System.out.println("  POST /api/analyze");
        System.out.println("  GET  /api/history");
        System.out.println("CORS allowed origin: " + ALLOWED_ORIGIN);
    }

    // ---------- API ----------
    private static void handleAnalyze(HttpExchange ex) throws IOException {
        cors(ex);
        if (ex.getRequestMethod().equals("OPTIONS")) { send(ex, 204, "text/plain", ""); return; }
        if (!ex.getRequestMethod().equals("POST")) { send(ex, 405, "application/json", "{\"error\":\"Use POST\"}"); return; }

        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        String review = jsonString(body, "review");
        int rating = 3;
        Matcher rm = Pattern.compile("\"rating\"\\s*:\\s*\"?(\\d)").matcher(body);
        if (rm.find()) rating = Integer.parseInt(rm.group(1));
        if (review == null || review.isBlank()) {
            send(ex, 400, "application/json", "{\"error\":\"Please enter a review\"}");
            return;
        }
        ReviewAnalyzer.Result r = analyzer.analyze(review, rating);
        history.add(new String[]{review, r.verdict(), String.valueOf(Math.round(r.score() * 100))});
        send(ex, 200, "application/json", toJson(r));
    }

    private static void handleHistory(HttpExchange ex) throws IOException {
        cors(ex);
        StringBuilder sb = new StringBuilder("[");
        synchronized (history) {
            for (int i = 0; i < history.size(); i++) {
                String[] h = history.get(i);
                if (i > 0) sb.append(',');
                sb.append("{\"review\":\"").append(esc(h[0])).append("\",\"verdict\":\"").append(h[1])
                  .append("\",\"score\":").append(h[2]).append('}');
            }
        }
        send(ex, 200, "application/json", sb.append(']').toString());
    }

    // ---------- helpers ----------
    private static void cors(HttpExchange ex) {
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", ALLOWED_ORIGIN);
        ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    }

    private static void send(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(code, code == 204 ? -1 : b.length);
        if (code != 204) ex.getResponseBody().write(b);
        ex.close();
    }

    private static String toJson(ReviewAnalyzer.Result r) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"score\":").append(String.format("%.2f", r.score()))
          .append(",\"verdict\":\"").append(r.verdict()).append('"')
          .append(",\"naiveBayes\":").append(String.format("%.2f", r.nbProb()))
          .append(",\"ruleScore\":").append(String.format("%.2f", r.ruleScore()))
          .append(",\"reasons\":[");
        for (int i = 0; i < r.reasons().size(); i++) {
            if (i > 0) sb.append(',');
            sb.append('"').append(esc(r.reasons().get(i))).append('"');
        }
        return sb.append("]}").toString();
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private static String jsonString(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"").matcher(json);
        if (!m.find()) return null;
        return m.group(1).replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\");
    }
}
